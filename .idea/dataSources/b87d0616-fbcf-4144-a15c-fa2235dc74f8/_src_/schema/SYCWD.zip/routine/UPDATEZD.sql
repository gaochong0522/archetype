CREATE PROCEDURE updateZD AS
v_id NUMBER;
v_unit_code VARCHAR2(255);
v_name VARCHAR2(255);
v_code VARCHAR2(255);
BEGIN
	DECLARE cursor updateInfo is 
	select et.id,ET.UNIT_CODE, TDEPT.name,TDEPT.code from equip_title et left join t_department@szcwdblink tdept on SUBSTR(et.unit_code, 0, 12) = tdept.code;  
BEGIN
open updateInfo;
loop
	fetch updateInfo into v_id,v_unit_code,v_name,v_code;
	EXIT WHEN updateInfo%NOTFOUND;
update EQUIP_TITLE  set ZD_NAME = v_name,ZD_CODE=v_code where id=v_id;
end loop;
close updateInfo;
end;
	-- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
END;
/

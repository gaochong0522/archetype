CREATE PROCEDURE sp_kill_idlesession  
AS
CURSOR c_kill_sqls 

IS Select 'ALTER SYSTEM DISCONNECT SESSION '''|| s.sid ||  ',' || s.serial# ||''' IMMEDIATE;' sqlstr From v$process p, v$session s  Where p.addr = s.paddr and status ='SNIPED' and s.username is not null;

BEGIN
FOR v_sql IN c_kill_sqls
  LOOP
    EXECUTE IMMEDIATE v_sql.sqlstr;
  END LOOP;
END;
/
